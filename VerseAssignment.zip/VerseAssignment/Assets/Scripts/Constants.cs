﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public  class Constants
{
    public static Color ColorProp = Color.yellow;
    public static Vector3 PlayerScale = Vector3.one;
}
