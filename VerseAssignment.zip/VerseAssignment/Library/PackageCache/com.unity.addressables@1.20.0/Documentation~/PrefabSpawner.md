---
uid: samples-prefab-spawner
---
# Prefab Spawner

This sample provides a basic script that instantiates and destroys a prefab `AssetReference`.

In order to use the sample, attach the provided script, `PrefabSpawnerSample`, to a `GameObject` in your scene.  Assign an `AdressableAsset` to the `AssetReference` field of that script.  If you're using the `Use Existing Build` playmode script, ensure that your Addressable content is built.  Then, enter playmode.