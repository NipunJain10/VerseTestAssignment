---
uid: samples-component-reference
---
# ComponentReference

This sample creates an AssetReference that is restricted to having a specific Component. 

For more information see the ComponentReference sample project located in the [Addressables Samples](https://github.com/Unity-Technologies/Addressables-Sample) repository.