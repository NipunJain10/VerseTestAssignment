---
uid: samples-custom-analyze-rules
---
# Custom Analyze Rules

This sample shows how to create custom AnalyzeRules for use within the Analyze window. Both rules follow the recommended pattern for adding themselves to the UI. 

For more information see the Custom Analyze Rule sample project located in the [Addressables Samples](https://github.com/Unity-Technologies/Addressables-Sample) repository.