---
uid: samples-import-existing-group
---
# Import Existing Group
This sample contains a tool that imports group assets (for example from a custom package) to the current project.

The tool is located under **Window/Asset Management/Addressables/Import Groups**.  The window requires a path to the `AddressableAssetGroup.asset` scriptable object, a name for the group, and a folder for any schemas related to the imported `AddressableAssetGroup`.