---
uid: samples-addressables-utility
---
# Addressables Utility
This sample contains a set of utility functions for Addressables.  Currently, the script contains a static method `GetAddressFromAssetReference` which provides the Addressable address used to reference a given `AssetRefence` internally.