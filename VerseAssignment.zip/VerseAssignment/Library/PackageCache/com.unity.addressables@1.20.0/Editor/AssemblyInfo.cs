using System.Reflection;
using System.Runtime.CompilerServices;
[assembly: AssemblyCompany("Unity Technologies")]
[assembly: InternalsVisibleTo("Unity.Addressables.Editor.Tests")]
[assembly: InternalsVisibleTo("Unity.Addressables.Tests")]
[assembly: InternalsVisibleTo("PerformanceTests.Editor")]
[assembly: InternalsVisibleTo("Unity.Localization.Editor")]