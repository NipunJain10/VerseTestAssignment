using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TestBehaviourWithReference : MonoBehaviour
{
    public Object Reference;
}
