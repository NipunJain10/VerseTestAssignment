using NUnit.Framework;

namespace AddressableAssets.DocExampleCode
{
    // Exists to so that the files in this folder can exist in Tests
    internal class TestStub
    {
        // A Test behaves as an ordinary method
        [Test]
        public void RequiredTest()
        {
            // Use the Assert class to test conditions
        }
    }
}
