using System;
using UnityEngine;

namespace UnityEditor.AddressableAssets.Tests
{
    class CustomTestSchemaSubClass : CustomTestSchema
    {
        public string customField2 = null;
    }
}
