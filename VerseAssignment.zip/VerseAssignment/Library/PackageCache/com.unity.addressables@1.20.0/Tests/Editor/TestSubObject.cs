using UnityEngine;

namespace UnityEditor.AddressableAssets.Tests
{
    public class TestSubObject : ScriptableObject
    {
    }
}
