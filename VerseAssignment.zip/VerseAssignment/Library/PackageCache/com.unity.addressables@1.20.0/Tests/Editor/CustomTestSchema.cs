using System;
using UnityEditor.AddressableAssets.Settings;
using UnityEngine;

namespace UnityEditor.AddressableAssets.Tests
{
    class CustomTestSchema : AddressableAssetGroupSchema
    {
        public string customField = null;
    }
}
